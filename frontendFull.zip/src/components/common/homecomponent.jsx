
import React from 'react'
import { Button } from 'react-bootstrap'
import { Link } from 'react-router-dom'
const Home = () => {
    return(
        <>

            <div>
            <div
      style={{
         backgroundImage: `url("https://thumbs.dreamstime.com/z/payroll-salary-payment-administrative-tiny-people-character-concept-vector-illustration-payroll-salary-payment-administrative-167701937.jpg")`,backgroundRepeat: 'no-repeat',width:'1515px',height:'690px',color:'white'
      }}>
        
      
                
                <center>
                    <br /><br /><br /><br />
                <h1>welcome to Payroll Application </h1>
                {/* <Link className="text-white " to={"/signin"}><li>Signin</li></Link> */}
                <br />
                <br />
                <Link to='/signin'><Button variant="btn btn-danger">Sign In</Button></Link>
                </center>
            <ul>
                
                
                 
                {/* <Link to='/signin'><li>Signin</li></Link> */}
            
            </ul>
            </div>
        </div>
        </>
    )
}
export default Home