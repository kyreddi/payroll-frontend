import React from 'react'

const UserDashboard = () => {
    return (
        <div>
            <h1>welcome user</h1>
        </div>
    )
}

export default UserDashboard
