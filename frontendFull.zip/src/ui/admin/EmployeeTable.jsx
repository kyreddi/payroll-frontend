import React from 'react'

const EmployeeTable = () => {
    return (
        <div>
            
        </div>
    )
}

export default EmployeeTable
