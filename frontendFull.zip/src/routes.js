//signin
export const Routes = {
    Signin: { path: "../components/common/Signin" },
};
