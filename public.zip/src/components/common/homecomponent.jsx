
import React from 'react'
import { Button } from 'react-bootstrap'
import { Link } from 'react-router-dom'
const Home = () => {
    return(
        <>

            <div>
                <center>
                <h1>welcome to Payroll Application </h1>
                {/* <Link className="text-white " to={"/signin"}><li>Signin</li></Link> */}
                <br />
                <br />
                <Link to='/signin'><Button variant="outline-success">Sign In</Button></Link>
                </center>
            <ul>
                
                
                 
                {/* <Link to='/signin'><li>Signin</li></Link> */}
            
            </ul>
        </div>
        </>
    )
}
export default Home