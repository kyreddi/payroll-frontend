import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { userSignin } from "../../actions/useractions/useraction";
import MessageBox from "./messagebox";
import "../../css/signin.css";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
const SignIn = (props) => {

    const dispatch = useDispatch();
    const [username, setUsername] = useState("")
    const [password, setPassword] = useState("")

    const userSignIn = useSelector(state => state.userSignin)
    const { loading,error,userInfo } = userSignIn



    const submitHandler = async(event) => {
        event.preventDefault();
       await  dispatch(userSignin(username, password))
    
        
    }

    useEffect(() => {
        if (userInfo) {
          
            
            props.history.push("/admindashboard")
             
        }
    }, [props.history, userInfo, dispatch])
    

    return (
        <>
                
<div className="Login">
      <Form onSubmit={submitHandler}>
        <Form.Group size="lg" controlId="email">
          <Form.Label>Email</Form.Label>
          <Form.Control
            autoFocus
            type="email"
            onChange={(event) => setUsername(event.target.value)}
          />
        </Form.Group>
        <Form.Group size="lg" controlId="password">
          <Form.Label>Password</Form.Label>
          <Form.Control
            type="password"
            onChange={(event) => setPassword(event.target.value)}
            
          />
        </Form.Group>
        <br />
        <center>
        <Button block size="lg" type="submit" >
          Login
        </Button>
        </center>
      </Form>
    </div>
        </>
    )
}
export default SignIn;