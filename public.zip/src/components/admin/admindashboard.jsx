import React from "react"
import { ProSidebar, Menu, MenuItem, SubMenu } from 'react-pro-sidebar';
import 'react-pro-sidebar/dist/css/styles.css';
import { Link } from "react-router-dom";
import AddEmployee from "../../ui/admin/addEmployee";
import SideBar from "./SideBar";
const admindashboard=(props)=>{
    return(
        <div >
         
           <SideBar />
           
           <h1>Welcome to Pay Roll Admin Panel</h1>
        </div>
    )
}
export default admindashboard